This is a PREINSTALL file for testing with.
