"use strict";

module.exports = {
  prepare: require("./prepare"),
  deploy: require("./deploy"),
  release: require("./release"),
};
