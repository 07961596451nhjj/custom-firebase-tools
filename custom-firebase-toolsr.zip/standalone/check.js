/*
  This file is used in firepit.js#VerifyNodePath() to test if the binary file is acting as a Node.js
  runtime or not. If it is acting as a runtime, then this script will return a checkmark, otherwise
  Firepit will respond with a non-checkmark log.
 */
console.log("✓");
